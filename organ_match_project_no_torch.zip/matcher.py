def match_score(recipient, donor):
    """
    recipient = (id, name, blood_group, organ_needed, urgency, city, status)
    donor     = (id, name, blood_group, organ_available, city, status)
    """

    _, _, r_bg, r_organ, r_urgency, r_city, _ = recipient
    _, _, d_bg, d_organ, d_city, _ = donor

    # Strict compatibility
    if r_bg != d_bg:
        return -9999
    if r_organ.lower() != d_organ.lower():
        return -9999

    score = 0
    score += 60  # blood group
    score += 50  # organ
    score += int(r_urgency) * 6  # urgency weight

    if r_city.lower().strip() == d_city.lower().strip():
        score += 10  # same city bonus

    return score


def find_best_matches(recipients, donor, top_k=3):
    scored = []
    for r in recipients:
        s = match_score(r, donor)
        if s > -9999:
            scored.append((s, r))

    scored.sort(reverse=True, key=lambda x: x[0])
    return scored[:top_k]
