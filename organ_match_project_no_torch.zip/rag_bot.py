# No-torch FAQ Search Bot (RAG-like)
# Works on Python 3.14 because it does NOT use sentence-transformers/torch.

FAQ_DOCS = [
    "Organ donation saves lives and helps patients with organ failure.",
    "Kidney transplant requires blood group compatibility and crossmatch tests.",
    "In emergency cases, the most urgent patient is prioritized.",
    "Documents required: ID proof, hospital consent forms, medical reports.",
    "If the first patient rejects, the organ is offered to the next best match.",
    "Hospitals coordinate transport and surgery scheduling after a match is confirmed."
]

def rag_answer(query: str, k: int = 2) -> str:
    if not query or not query.strip():
        return "Please ask a question."

    q = query.lower().strip()
    q_words = [w for w in q.replace("?", "").replace(".", "").split() if len(w) > 2]

    scored = []
    for doc in FAQ_DOCS:
        d = doc.lower()
        score = sum(1 for w in q_words if w in d)
        scored.append((score, doc))

    scored.sort(reverse=True, key=lambda x: x[0])
    best = [doc for score, doc in scored if score > 0][:k]

    if not best:
        return "No FAQ match found. Try asking about: documents, urgency, rejection, transplant steps."

    return "\n".join(best)
