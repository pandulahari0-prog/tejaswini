import sqlite3

DB_NAME = "organ_match.db"

def init_db():
    conn = sqlite3.connect(DB_NAME)
    cur = conn.cursor()

    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS recipients (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            blood_group TEXT NOT NULL,
            organ_needed TEXT NOT NULL,
            urgency INTEGER NOT NULL,
            city TEXT NOT NULL,
            status TEXT DEFAULT 'ACTIVE'
        )
        """
    )

    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS donors (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            blood_group TEXT NOT NULL,
            organ_available TEXT NOT NULL,
            city TEXT NOT NULL,
            status TEXT DEFAULT 'AVAILABLE'
        )
        """
    )

    conn.commit()
    conn.close()


def add_recipient(name, blood_group, organ_needed, urgency, city):
    conn = sqlite3.connect(DB_NAME)
    cur = conn.cursor()
    cur.execute(
        """
        INSERT INTO recipients (name, blood_group, organ_needed, urgency, city)
        VALUES (?, ?, ?, ?, ?)
        """,
        (name, blood_group, organ_needed, int(urgency), city),
    )
    conn.commit()
    conn.close()


def add_donor(name, blood_group, organ_available, city):
    conn = sqlite3.connect(DB_NAME)
    cur = conn.cursor()
    cur.execute(
        """
        INSERT INTO donors (name, blood_group, organ_available, city)
        VALUES (?, ?, ?, ?)
        """,
        (name, blood_group, organ_available, city),
    )
    conn.commit()
    conn.close()


def get_active_recipients():
    conn = sqlite3.connect(DB_NAME)
    cur = conn.cursor()
    cur.execute("SELECT * FROM recipients WHERE status='ACTIVE'")
    rows = cur.fetchall()
    conn.close()
    return rows


def get_available_donors():
    conn = sqlite3.connect(DB_NAME)
    cur = conn.cursor()
    cur.execute("SELECT * FROM donors WHERE status='AVAILABLE'")
    rows = cur.fetchall()
    conn.close()
    return rows


def mark_recipient_rejected(recipient_id):
    conn = sqlite3.connect(DB_NAME)
    cur = conn.cursor()
    cur.execute("UPDATE recipients SET status='REJECTED' WHERE id=?", (recipient_id,))
    conn.commit()
    conn.close()
