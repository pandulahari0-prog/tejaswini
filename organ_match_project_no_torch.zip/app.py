import streamlit as st

from db import (
    init_db,
    add_recipient,
    add_donor,
    get_active_recipients,
    get_available_donors,
    mark_recipient_rejected,
)
from matcher import find_best_matches
from rag_bot import rag_answer

init_db()

st.set_page_config(page_title="Organ Match System", page_icon="🩺", layout="centered")
st.title("🩺 Organ Donation & Recipient Matching System")
st.caption("AI Matching + SQLite Database + FAQ Chatbot (No Torch)")

tab1, tab2, tab3 = st.tabs(["➕ Add Data", "🤖 AI Matching", "💬 Chatbot"])

with tab1:
    st.subheader("Add Recipient")
    with st.form("recipient_form"):
        r_name = st.text_input("Recipient Name")
        r_bg = st.selectbox("Blood Group", ["A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-"])
        r_organ = st.selectbox("Organ Needed", ["Kidney", "Liver", "Heart", "Lung"])
        r_urgency = st.slider("Urgency (1 low - 10 high)", 1, 10, 5)
        r_city = st.text_input("City")
        submitted_r = st.form_submit_button("Add Recipient")

    if submitted_r:
        if not (r_name and r_city):
            st.error("Please enter Recipient Name and City.")
        else:
            add_recipient(r_name, r_bg, r_organ, r_urgency, r_city)
            st.success("Recipient added successfully!")

    st.divider()

    st.subheader("Add Donor")
    with st.form("donor_form"):
        d_name = st.text_input("Donor Name")
        d_bg = st.selectbox("Donor Blood Group", ["A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-"])
        d_organ = st.selectbox("Organ Available", ["Kidney", "Liver", "Heart", "Lung"])
        d_city = st.text_input("Donor City")
        submitted_d = st.form_submit_button("Add Donor")

    if submitted_d:
        if not (d_name and d_city):
            st.error("Please enter Donor Name and City.")
        else:
            add_donor(d_name, d_bg, d_organ, d_city)
            st.success("Donor added successfully!")


with tab2:
    st.subheader("AI Match Donor → Best Recipients (with alternatives)")

    donors = get_available_donors()
    recipients = get_active_recipients()

    if len(donors) == 0:
        st.warning("No donors available. Please add donor data first.")
    elif len(recipients) == 0:
        st.warning("No active recipients. Please add recipient data first.")
    else:
        donor_options = {f"{d[0]} - {d[1]} ({d[3]} | {d[2]})": d for d in donors}
        selected_label = st.selectbox("Select Donor", list(donor_options.keys()))
        donor = donor_options[selected_label]

        top_matches = find_best_matches(recipients, donor, top_k=3)

        if not top_matches:
            st.error("No compatible recipients found for this donor.")
        else:
            st.write("### 🔥 Top Matches")
            for i, (score, r) in enumerate(top_matches, start=1):
                st.write(
                    f"**{i}. {r[1]}** | BG: {r[2]} | Organ: {r[3]} | "
                    f"Urgency: {r[4]} | City: {r[5]} | Score: {score}"
                )

            st.divider()
            st.write("### ❌ Demo: Reject 1st match and move to next")
            if st.button("Reject 1st Match"):
                first_match = top_matches[0][1]
                mark_recipient_rejected(first_match[0])
                st.warning(f"{first_match[1]} marked as REJECTED. Refresh to see next match.")


with tab3:
    st.subheader("FAQ Chatbot (No Torch)")
    query = st.text_input("Ask a question", placeholder="Example: What if first patient rejects?")

    if st.button("Ask"):
        st.info(rag_answer(query))
