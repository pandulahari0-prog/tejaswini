# Organ Donation & Recipient Matching System (No Torch Version)

This version runs on newer Python versions (including 3.14) because it DOES NOT use:
- torch
- sentence-transformers
- faiss

It uses a simple keyword-based FAQ search (RAG-like) chatbot.

## Install
```bash
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

## Run
```bash
python -m streamlit run app.py
```
